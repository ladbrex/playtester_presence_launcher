playtester.io Presence Launcher
Version 0.1
Created by Ladbrex
Based on playtester.io by Shaan
 
---
 
About this tool
 
This is a custom-built Rich Presence launcher for Discord.
 
It allows users to show a dynamic “Now Playing” status in Discord, rotating every 15 seconds between:
- ~1.4K games
- x online / x members (live data from the official Playtester Discord)
 
This launcher uses the official Playtester branding and is built for fans, testers, and community members who want to represent Playtester.io on their profile.
 
---
 
Features
 
- Discord Rich Presence with dynamic content
- Updates presence in real time
- Beautiful custom UI inspired by playtester.io
- Start/Stop button for control
- Timer starts and continues to count upward accurately
- Fully standalone .exe – no installation needed
- No Python or terminal required
 
Automatic Updates
 
This version does not include an auto-updater.
If you want future versions, keep an eye on Discord. (.gg/playtesterhq)
 
---
 
Requirements
 
- Windows 10 or newer
- Discord must be running in the background
- Internet connection (for Discord server data)
 
---
 
Credits
 
- Original platform: playtester.io by Shaan
- Presence Launcher: Designed & developed by Ladbrex
- Powered by:
  - pypresence (Python Discord RPC lib)
  - Tkinter (UI framework)
  - PyInstaller (for .exe packaging)